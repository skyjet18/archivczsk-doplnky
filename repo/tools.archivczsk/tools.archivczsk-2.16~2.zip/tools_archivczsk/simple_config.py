# currently just reimport classes directly from ArchivCZSK
# this can be extended in the future
from Plugins.Extensions.archivCZSK.gui.config import SimpleConfigSelection, SimpleConfigText, SimpleConfigNumber, SimpleConfigInteger, SimpleConfigYesNo, SimpleConfigMultiSelection
